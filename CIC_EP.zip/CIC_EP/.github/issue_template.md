# Prerequisites

Please answer the following questions before submitting an issue. **YOU MAY DELETE THE PREREQUISITES SECTION.**

- What is your product version?
- What is your product type (Angular or MVC)?
- What is product framework type (.net framework or .net core)?

## If issue related with ABP Framework

- What is ABP Framework version?

## If issue is about UI

- Which theme are you using?
- What are the theme settings?
