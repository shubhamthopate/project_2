export interface IRolesWithOrganizationUnit {
    roleIds: number[];
    ouId: number;
}
